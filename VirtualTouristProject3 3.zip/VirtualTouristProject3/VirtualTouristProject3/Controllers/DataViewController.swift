//
//  DataViewController.swift
//  VirtualTouristProject3
//
//  Created by Razan on 24/01/2021.
//
import Foundation
import CoreData

class DataController {
    
    let persistentContainer: NSPersistentContainer
    var viewContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    init(modelName: String) {
        persistentContainer = NSPersistentContainer(name: modelName)
    }
    
    func load(completion: (() -> Void)? = nil) {
        persistentContainer.loadPersistentStores { (storeDescription, error) in
            guard error == nil else {
                print(error!.localizedDescription)
                return
            }
            self.autoSaveViewContext()
            completion?()
        }
    }
    func autoSaveViewContext(interval: TimeInterval = 5) {
        print("Save made")
        guard interval > 0 else {
            print("Cannot autosave")
            return
        }
        
        if viewContext.hasChanges {
            try? viewContext.save()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + interval) {
            self.autoSaveViewContext(interval: interval)
        }
    }
}
