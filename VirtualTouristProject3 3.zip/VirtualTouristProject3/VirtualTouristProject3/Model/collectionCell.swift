//
//  collectionCell.swift
//  VirtualTouristProject3
//
//  Created by Razan on 24/01/2021.
//
import UIKit

class collectionCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    override var isSelected: Bool {
        didSet {
            backgroundColor = isSelected ? UIColor.lightGray : UIColor.clear
        }
    }
}
