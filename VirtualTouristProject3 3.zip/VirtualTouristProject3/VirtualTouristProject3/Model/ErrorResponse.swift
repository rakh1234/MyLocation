//
//  ErrorResponse.swift
//  VirtualTouristProject3
//
//  Created by Razan on 24/01/2021.
//
import Foundation

struct errorResponse: Codable {
    var status: String
    var code: Int
    var message: String
    
    enum CodingKeys: String, CodingKey {
        case status = "stat"
        case code
        case message
    }
}
