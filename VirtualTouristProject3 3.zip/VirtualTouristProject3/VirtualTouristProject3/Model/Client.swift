//
//  Client.swift
//  VirtualTouristProject3
//
//  Created by Razan on 24/01/2021.
//
import Foundation
import UIKit

class Client {
    
    static let apiKey = "27026cc0ef7afad741d925264fe04753"
    static let secretKey = "63f30d8b1d91fffe"
    
    enum Endpoint{
       static let flickrbaseURL = "https://www.flickr.com/services/rest/?method=flickr.photos.search&"
       static let flickrApiKey = "api_key=\(Client.apiKey)"
       static let flickrPoint = "&media=Photo&per_page=25&extras=url_m&format=json"

      case flickrSearchImageURL(Double, Double)
    
        var stringValue: String{
            switch self {
            case .flickrSearchImageURL(let lat,let lon):
                return Endpoint.flickrbaseURL + Endpoint.flickrApiKey + "&lat=\(lat)&lon=\(lon)" + "&page=\(Int.random(in: 0..<3000))" + Endpoint.flickrPoint
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    class func getImageDetailsFromFlickr(lat: Double, lon: Double, completion: @escaping ([Photo], Error?) -> Void ) {
        taskGETRequest(url: Endpoint.flickrSearchImageURL(lat,lon).url, response: photoClass.self) { (response, error) in
            print(Endpoint.flickrSearchImageURL(lat,lon).url)
            if let response = response {
                completion(response.photos.photo, nil)
            } else {
                completion([], error)
            }
        }
    }
    
    class func getImage(imageUrl: String, completion: @escaping(Data?, Error?) -> Void) {
        let task = URLSession.shared.dataTask(with: URL(string: imageUrl)!) { (data, response, error) in
            guard let data = data else {
                completion(nil, error)
                return
            }
            DispatchQueue.main.async {
                completion(data, nil)
            }
        }
        task.resume()
    }
    
    class func taskGETRequest<Response: Decodable>(url: URL, response: Response.Type, completion: @escaping (Response?, Error?) -> Void) {
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else {
                completion(nil, error)
                return
            }
            let decoder = JSONDecoder()
            
            do {
                let range = (14..<data.count)
                var newData = data.subdata(in: range)
                _ = newData.popLast()
                let object = try decoder.decode(Response.self, from: newData)
                DispatchQueue.main.async {
                    completion(object, nil)
                }
            } catch {
                do {
                    let failResponse = try decoder.decode(errorResponse.self, from: data)
                    DispatchQueue.main.async {
                        completion(nil, failResponse as? Error)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
            }
        }
        task.resume()
    }
    
    public static func searchForPhotoes(pin: Location) {
        let latitude = pin.latitude
        let longitude = pin.longitude
        let paramters: [String: Any] = ["method": "flickr.photos.search",
                         
                         "latitude": latitude,
                         "longitude": longitude,
                         "format": "json",
                         "nojsoncallback": 1,
                         "page": Int(arc4random_uniform(UInt32(20))) % 20]
     }
}
